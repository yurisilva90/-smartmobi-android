# SmartMobi Android WebView

Este projeto gera um APK Android que abre o SmartMobi fora do navegador, usando WebView.

URL configurada:
https://relaxed-taffy-010519.netlify.app/

## Como gerar o APK sem Android Studio

1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta para o repositório.
3. Vá em **Actions**.
4. Abra **Build SmartMobi APK**.
5. Clique em **Run workflow**.
6. Ao terminar, baixe o arquivo em **Artifacts**: `SmartMobi-debug-apk`.

## Observação

Este APK abre o app fora do navegador. Para GPS em segundo plano real ou botão sobre outros apps, será necessário evoluir para app Android nativo com permissões específicas.
